module.exports.function = function notice (find) { //공지사항
  var http = require('http')
  var result = http.getUrl("https://api.sheety.co/eee1ab1f-428e-4e85-83c8-eb262c364ed4",{format : 'json'})

  return result
} 